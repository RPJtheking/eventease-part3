using EventEase.Data;
using EventEase.Middleware;
using EventEase.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Register EF Core with SQL Server (works for both LocalDB in development
// and Azure SQL Database once deployed - only the connection string changes).
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Part 2 A: Azure Blob Storage for Venue/Event images.
builder.Services.AddScoped<IBlobStorageService, BlobStorageService>();

var app = builder.Build();

// Apply pending migrations at startup. This creates/updates the consolidated
// vw_BookingDetails view and the Part 3 EventTypes / availability changes before
// any page queries them.
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    var logger = scope.ServiceProvider.GetRequiredService<ILoggerFactory>()
        .CreateLogger("DatabaseStartup");

    try
    {
        db.Database.Migrate();
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Database migration failed: {Message}", ex.GetBaseException().Message);

        // Safety net: apply the Part 3 changes directly. Every batch is idempotent, so
        // this is harmless if some or all of it is already in place.
        try
        {
            foreach (var statement in Part3Schema.Statements)
            {
                db.Database.ExecuteSqlRaw(statement);
            }
            logger.LogWarning("Part 3 schema changes were applied directly after the migration failed.");
        }
        catch (Exception fallbackEx)
        {
            logger.LogError(fallbackEx, "Part 3 schema fallback also failed: {Message}", fallbackEx.GetBaseException().Message);
        }
    }
}

// Part 2 B: catch anything that slips past controller-level try/catch blocks so
// the app degrades gracefully instead of crashing.
app.UseMiddleware<ExceptionHandlingMiddleware>();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseStatusCodePagesWithReExecute("/Home/Error", "?statusCode={0}");

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
