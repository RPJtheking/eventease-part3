using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EventEase.Migrations
{
    /// <inheritdoc />
    public partial class AddBookingDetailsView : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Part 2 A: images are now uploaded to Azure Blob Storage after the
            // record is validated, so ImageUrl is no longer guaranteed to be
            // populated at the exact moment the row is inserted/updated.
            migrationBuilder.AlterColumn<string>(
                name: "ImageUrl",
                table: "Venues",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            // Part 2 C: consolidated, read-only view joining Bookings with their
            // related Event and Venue rows, used to power the enhanced booking
            // display and the BookingID / Event Name search.
            migrationBuilder.Sql(@"
CREATE VIEW vw_BookingDetails AS
SELECT
    b.BookingId,
    b.BookingDate,
    e.EventId,
    e.EventName,
    e.EventDate,
    e.Description   AS EventDescription,
    e.ImageUrl       AS EventImageUrl,
    v.VenueId,
    v.VenueName,
    v.Location        AS VenueLocation,
    v.Capacity         AS VenueCapacity,
    v.ImageUrl          AS VenueImageUrl
FROM dbo.Bookings b
INNER JOIN dbo.Events e ON e.EventId = b.EventId
INNER JOIN dbo.Venues v ON v.VenueId = b.VenueId;
");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.Sql("DROP VIEW IF EXISTS vw_BookingDetails;");

            migrationBuilder.AlterColumn<string>(
                name: "ImageUrl",
                table: "Venues",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);
        }
    }
}
