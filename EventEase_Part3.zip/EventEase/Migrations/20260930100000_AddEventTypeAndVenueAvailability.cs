using EventEase.Data;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace EventEase.Migrations
{
    /// <inheritdoc />
    public partial class AddEventTypeAndVenueAvailability : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // Part 3: EventTypes lookup, Venues.IsAvailable, Events.EventTypeId and the
            // rebuilt vw_BookingDetails view. The steps are idempotent SQL batches (see
            // Part3Schema) so this migration succeeds even if the database was already
            // partly updated by hand or by an earlier failed attempt.
            foreach (var statement in Part3Schema.Statements)
            {
                migrationBuilder.Sql(statement);
            }
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Restore the Part 2 version of the view before dropping the columns it used.
            migrationBuilder.Sql("DROP VIEW IF EXISTS dbo.vw_BookingDetails;");
            migrationBuilder.Sql(@"
CREATE VIEW dbo.vw_BookingDetails AS
SELECT
    b.BookingId,
    b.BookingDate,
    e.EventId,
    e.EventName,
    e.EventDate,
    e.Description   AS EventDescription,
    e.ImageUrl       AS EventImageUrl,
    v.VenueId,
    v.VenueName,
    v.Location        AS VenueLocation,
    v.Capacity         AS VenueCapacity,
    v.ImageUrl          AS VenueImageUrl
FROM dbo.Bookings b
INNER JOIN dbo.Events e ON e.EventId = b.EventId
INNER JOIN dbo.Venues v ON v.VenueId = b.VenueId;
");

            migrationBuilder.DropForeignKey(
                name: "FK_Events_EventTypes_EventTypeId",
                table: "Events");

            migrationBuilder.DropTable(
                name: "EventTypes");

            migrationBuilder.DropIndex(
                name: "IX_Events_EventTypeId",
                table: "Events");

            migrationBuilder.DropColumn(
                name: "IsAvailable",
                table: "Venues");

            migrationBuilder.DropColumn(
                name: "EventTypeId",
                table: "Events");
        }
    }
}
