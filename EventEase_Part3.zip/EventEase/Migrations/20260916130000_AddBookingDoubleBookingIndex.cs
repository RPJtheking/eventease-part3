using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EventEase.Migrations
{
    /// <inheritdoc />
    public partial class AddBookingDoubleBookingIndex : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // The plain single-column index on VenueId (auto-created for the FK) is
            // superseded by the composite unique index below, which still covers FK
            // lookups on VenueId but also enforces the Part 2 B double-booking rule
            // at the database level: a venue cannot be booked twice for the same
            // date AND time.
            migrationBuilder.DropIndex(
                name: "IX_Bookings_VenueId",
                table: "Bookings");

            migrationBuilder.CreateIndex(
                name: "UX_Bookings_Venue_Date",
                table: "Bookings",
                columns: new[] { "VenueId", "BookingDate" },
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "UX_Bookings_Venue_Date",
                table: "Bookings");

            migrationBuilder.CreateIndex(
                name: "IX_Bookings_VenueId",
                table: "Bookings",
                column: "VenueId");
        }
    }
}
