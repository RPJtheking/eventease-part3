using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;

namespace EventEase.Services
{
    /// <summary>
    /// Uploads Venue and Event images to an Azure Blob Storage container and
    /// returns the resulting public URL to be saved on the entity.
    /// </summary>
    public class BlobStorageService : IBlobStorageService
    {
        private readonly string _connectionString;
        private readonly string _containerName;
        private readonly ILogger<BlobStorageService> _logger;

        // Kept small and explicit for Part 2's "prevent crashes on user error" requirement -
        // we validate before ever touching the network call.
        private static readonly string[] AllowedExtensions = { ".jpg", ".jpeg", ".png", ".gif", ".webp" };
        private const long MaxFileSizeBytes = 5 * 1024 * 1024; // 5 MB

        public BlobStorageService(IConfiguration configuration, ILogger<BlobStorageService> logger)
        {
            _connectionString = configuration["AzureBlobStorage:ConnectionString"] ?? string.Empty;
            _containerName = configuration["AzureBlobStorage:ContainerName"] ?? "eventease-images";
            _logger = logger;
        }

        public async Task<string> UploadImageAsync(IFormFile file)
        {
            if (file == null || file.Length == 0)
            {
                throw new ArgumentException("Please choose an image file to upload.");
            }

            if (file.Length > MaxFileSizeBytes)
            {
                throw new ArgumentException("The image is too large. Please upload a file smaller than 5 MB.");
            }

            var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
            if (string.IsNullOrEmpty(extension) || !AllowedExtensions.Contains(extension))
            {
                throw new ArgumentException("Unsupported image type. Please upload a JPG, PNG, GIF or WEBP file.");
            }

            if (string.IsNullOrWhiteSpace(_connectionString))
            {
                // Fail loudly with a friendly message rather than letting the SDK throw
                // a raw connection exception straight into the user's face.
                throw new InvalidOperationException(
                    "Image storage is not configured. Please set AzureBlobStorage:ConnectionString in appsettings/App Service configuration.");
            }

            try
            {
                var containerClient = new BlobContainerClient(_connectionString, _containerName);
                await containerClient.CreateIfNotExistsAsync(PublicAccessType.Blob);

                var blobName = $"{Guid.NewGuid()}{extension}";
                var blobClient = containerClient.GetBlobClient(blobName);

                await using (var stream = file.OpenReadStream())
                {
                    await blobClient.UploadAsync(stream, new BlobHttpHeaders { ContentType = file.ContentType });
                }

                return blobClient.Uri.ToString();
            }
            catch (Exception ex) when (ex is not ArgumentException)
            {
                _logger.LogError(ex, "Failed to upload image {FileName} to Azure Blob Storage.", file.FileName);
                throw new InvalidOperationException("We couldn't upload that image right now. Please try again.", ex);
            }
        }

        public async Task DeleteImageAsync(string? imageUrl)
        {
            if (string.IsNullOrWhiteSpace(imageUrl) || string.IsNullOrWhiteSpace(_connectionString))
            {
                return;
            }

            try
            {
                var containerClient = new BlobContainerClient(_connectionString, _containerName);

                // Only attempt to delete blobs that actually live in our container -
                // ignore seeded picsum.photos placeholder URLs, external links, etc.
                if (!imageUrl.Contains(containerClient.Uri.Host, StringComparison.OrdinalIgnoreCase))
                {
                    return;
                }

                var blobName = Path.GetFileName(new Uri(imageUrl).LocalPath);
                if (!string.IsNullOrWhiteSpace(blobName))
                {
                    await containerClient.GetBlobClient(blobName).DeleteIfExistsAsync();
                }
            }
            catch (Exception ex)
            {
                // Deleting an old image is a courtesy cleanup step, not something that
                // should ever block or crash the user's request.
                _logger.LogWarning(ex, "Failed to delete blob for image URL {ImageUrl}.", imageUrl);
            }
        }
    }
}
