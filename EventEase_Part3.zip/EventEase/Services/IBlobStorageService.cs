namespace EventEase.Services
{
    /// <summary>
    /// Abstraction over Azure Blob Storage so controllers never talk to the
    /// Azure SDK directly. Part 2 requirement: images must be stored in an
    /// Azure Storage Service rather than saved as plain URLs.
    /// </summary>
    public interface IBlobStorageService
    {
        /// <summary>
        /// Uploads a file to the configured blob container and returns the public
        /// URL that should be stored on the entity (Venue.ImageUrl / Event.ImageUrl).
        /// </summary>
        Task<string> UploadImageAsync(IFormFile file);

        /// <summary>
        /// Best-effort delete of a previously uploaded blob, identified by its full
        /// public URL. Safe to call with URLs that do not belong to this container
        /// (e.g. the seeded picsum.photos placeholders) - it simply does nothing.
        /// </summary>
        Task DeleteImageAsync(string? imageUrl);
    }
}
