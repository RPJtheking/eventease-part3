
## Consolidated Booking Dashboard
The Bookings page now presents a professional consolidated dashboard powered by the `vw_BookingDetails` SQL view. It displays Booking ID, Event information and image, Event Date, Venue information and image, Venue Location, Capacity and Booking Date in one table. The page also includes summary cards and a search function for Booking ID or Event Name.

If the Bookings page reports that the consolidated view is unavailable, apply the EF Core migrations or run `EventEase/Database/Part2_BookingView.sql` against the application's database.
