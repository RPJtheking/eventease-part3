using Microsoft.AspNetCore.Mvc.Rendering;

namespace EventEase.Models
{
    /// <summary>
    /// Aggregates matches from Venues, Events, and Bookings for the site-wide
    /// search, together with the Part 3 filters (event type, date range and
    /// venue availability) that were applied.
    /// </summary>
    public class SearchResultsViewModel
    {
        public string? Query { get; set; }

        // ---- Part 3 filters ----
        public int? EventTypeId { get; set; }
        public DateTime? DateFrom { get; set; }
        public DateTime? DateTo { get; set; }

        /// <summary>"available", "unavailable" or empty/null for any.</summary>
        public string? Availability { get; set; }

        /// <summary>Populates the Event Type drop-down.</summary>
        public List<SelectListItem> EventTypes { get; set; } = new();

        public List<Venue> Venues { get; set; } = new();
        public List<Event> Events { get; set; } = new();
        public List<BookingDetailsView> Bookings { get; set; } = new();

        public bool HasKeyword => !string.IsNullOrWhiteSpace(Query);

        public bool HasFilters =>
            EventTypeId.HasValue ||
            DateFrom.HasValue ||
            DateTo.HasValue ||
            !string.IsNullOrWhiteSpace(Availability);

        /// <summary>True once the user has entered a keyword and/or chosen any filter.</summary>
        public bool HasSearched => HasKeyword || HasFilters;

        public int TotalResults => Venues.Count + Events.Count + Bookings.Count;
    }
}
