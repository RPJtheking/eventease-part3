using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventEase.Models
{
    /// <summary>
    /// Represents a physical location that can host events (e.g. a hall, garden or conference room).
    /// </summary>
    public class Venue
    {
        [Key]
        public int VenueId { get; set; }

        [Required(ErrorMessage = "Please enter the venue name.")]
        [StringLength(150)]
        [Display(Name = "Venue Name")]
        public string VenueName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter the venue location.")]
        [StringLength(200)]
        public string Location { get; set; } = string.Empty;

        [Required]
        [Range(1, 100000, ErrorMessage = "Capacity must be a positive number.")]
        public int Capacity { get; set; }

        // Part 3: availability flag used by the search filters. Defaults to true so
        // existing and newly created venues are bookable unless marked otherwise.
        [Display(Name = "Available for booking")]
        public bool IsAvailable { get; set; } = true;

        // Part 2: this now holds the public URL of the blob in Azure Storage,
        // set by the controller after a successful upload - it is never bound
        // directly from user input, so it is not [Required] at the model level.
        [Display(Name = "Image")]
        public string? ImageUrl { get; set; }

        // Not persisted - used only to receive the uploaded file from the form.
        [NotMapped]
        [Display(Name = "Venue Image")]
        public IFormFile? ImageFile { get; set; }

        // Navigation properties
        public ICollection<Event>? Events { get; set; }
        public ICollection<Booking>? Bookings { get; set; }
    }
}
