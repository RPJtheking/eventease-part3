using System.ComponentModel.DataAnnotations;

namespace EventEase.Models
{
    /// <summary>
    /// Part 3: lookup table of predefined event categories (Wedding, Conference, ...).
    /// Booking specialists pick one when capturing an Event and can then filter
    /// search results by it.
    /// </summary>
    public class EventType
    {
        [Key]
        public int EventTypeId { get; set; }

        [Required]
        [StringLength(100)]
        [Display(Name = "Event Type")]
        public string Name { get; set; } = string.Empty;

        public ICollection<Event>? Events { get; set; }
    }
}
