using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EventEase.Models
{
    /// <summary>
    /// Represents an event that a customer has requested. An event can be captured
    /// before a venue has been confirmed for it (VenueId is nullable) - once a venue
    /// is available, a Booking record is created to link the two together.
    /// </summary>
    public class Event
    {
        [Key]
        public int EventId { get; set; }

        [Required(ErrorMessage = "Please enter the event name.")]
        [StringLength(150)]
        [Display(Name = "Event Name")]
        public string EventName { get; set; } = string.Empty;

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Event Date")]
        public DateTime EventDate { get; set; }

        [StringLength(1000)]
        public string? Description { get; set; }

        // Nullable: an event may be captured before it has been assigned a venue.
        [Display(Name = "Venue")]
        public int? VenueId { get; set; }

        [ForeignKey(nameof(VenueId))]
        public Venue? Venue { get; set; }

        // Part 3: classification of the event (Wedding, Conference, ...), taken from
        // the EventTypes lookup table. Nullable so existing events remain valid.
        [Display(Name = "Event Type")]
        public int? EventTypeId { get; set; }

        [ForeignKey(nameof(EventTypeId))]
        public EventType? EventType { get; set; }

        // Part 2: holds the public URL of the blob in Azure Storage, set by the
        // controller after a successful upload.
        [Display(Name = "Image")]
        public string? ImageUrl { get; set; }

        // Not persisted - used only to receive the uploaded file from the form.
        [NotMapped]
        [Display(Name = "Event Image")]
        public IFormFile? ImageFile { get; set; }

        public ICollection<Booking>? Bookings { get; set; }
    }
}
