namespace EventEase.Models
{
    /// <summary>
    /// Read-only projection mapped to the "vw_BookingDetails" SQL view (see the
    /// AddBookingDetailsView migration). Part 2 requirement: consolidate booking,
    /// event and venue information into a single, richer view for booking
    /// specialists, without denormalizing the underlying Booking/Event/Venue tables.
    /// This type has no primary key by design - EF Core maps it with HasNoKey().
    /// </summary>
    public class BookingDetailsView
    {
        public int BookingId { get; set; }
        public DateTime BookingDate { get; set; }

        public int EventId { get; set; }
        public string EventName { get; set; } = string.Empty;
        public DateTime EventDate { get; set; }
        public string? EventDescription { get; set; }
        public string? EventImageUrl { get; set; }
        public int? EventTypeId { get; set; }
        public string? EventTypeName { get; set; }

        public int VenueId { get; set; }
        public string VenueName { get; set; } = string.Empty;
        public string VenueLocation { get; set; } = string.Empty;
        public int VenueCapacity { get; set; }
        public string? VenueImageUrl { get; set; }
        public bool VenueIsAvailable { get; set; }
    }
}
