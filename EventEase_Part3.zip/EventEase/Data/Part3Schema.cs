namespace EventEase.Data
{
    /// <summary>
    /// Part 3: the database changes for the EventTypes lookup, Venues.IsAvailable,
    /// Events.EventTypeId and the rebuilt vw_BookingDetails view, written as small
    /// IDEMPOTENT SQL batches (each one checks whether its change already exists).
    ///
    /// Why: the same list is used by the EF migration AND by a startup safety net in
    /// Program.cs. That means the schema ends up correct whether the database is fresh,
    /// was partly changed by hand, or an earlier migration attempt failed half way -
    /// running it twice is harmless.
    /// Each entry is sent as its own batch (CREATE VIEW must be alone in a batch, and a
    /// new column can't be referenced in the same batch that adds it).
    /// </summary>
    public static class Part3Schema
    {
        public static readonly string[] Statements =
        {
            // 1. EventTypes lookup table
            @"IF OBJECT_ID(N'dbo.EventTypes', N'U') IS NULL
CREATE TABLE dbo.EventTypes (
    EventTypeId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_EventTypes PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL
);",

            @"IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_EventTypes_Name' AND object_id = OBJECT_ID(N'dbo.EventTypes'))
CREATE UNIQUE INDEX IX_EventTypes_Name ON dbo.EventTypes (Name);",

            // 2. Predefined categories (skips any id or name that already exists)
            @"SET IDENTITY_INSERT dbo.EventTypes ON;
INSERT INTO dbo.EventTypes (EventTypeId, Name)
SELECT v.EventTypeId, v.Name
FROM (VALUES
    (1, N'Wedding'),
    (2, N'Conference'),
    (3, N'Gala / Fundraiser'),
    (4, N'Corporate Function'),
    (5, N'Birthday / Celebration'),
    (6, N'Concert / Performance'),
    (7, N'Exhibition / Expo'),
    (8, N'Other')
) AS v (EventTypeId, Name)
WHERE NOT EXISTS (SELECT 1 FROM dbo.EventTypes t WHERE t.EventTypeId = v.EventTypeId OR t.Name = v.Name);
SET IDENTITY_INSERT dbo.EventTypes OFF;",

            // 3. Venue availability (existing venues default to available)
            @"IF COL_LENGTH(N'dbo.Venues', N'IsAvailable') IS NULL
ALTER TABLE dbo.Venues ADD IsAvailable BIT NOT NULL CONSTRAINT DF_Venues_IsAvailable DEFAULT 1;",

            // 4. Event type on Events
            @"IF COL_LENGTH(N'dbo.Events', N'EventTypeId') IS NULL
ALTER TABLE dbo.Events ADD EventTypeId INT NULL;",

            @"IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Events_EventTypeId' AND object_id = OBJECT_ID(N'dbo.Events'))
CREATE INDEX IX_Events_EventTypeId ON dbo.Events (EventTypeId);",

            @"IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Events_EventTypes_EventTypeId')
ALTER TABLE dbo.Events ADD CONSTRAINT FK_Events_EventTypes_EventTypeId
    FOREIGN KEY (EventTypeId) REFERENCES dbo.EventTypes (EventTypeId);",

            // 5. Classify the three original sample events (only if still unclassified)
            @"UPDATE dbo.Events SET EventTypeId = 1 WHERE EventId = 1 AND EventName = N'Smith Wedding' AND EventTypeId IS NULL;
UPDATE dbo.Events SET EventTypeId = 2 WHERE EventId = 2 AND EventName = N'Annual Tech Conference' AND EventTypeId IS NULL;
UPDATE dbo.Events SET EventTypeId = 3 WHERE EventId = 3 AND EventName = N'Charity Gala' AND EventTypeId IS NULL;",

            // 6. Rebuild vw_BookingDetails with event type + venue availability.
            //    Only rebuilt when it doesn't have the new column yet.
            @"IF COL_LENGTH(N'dbo.vw_BookingDetails', N'VenueIsAvailable') IS NULL
BEGIN
    IF OBJECT_ID(N'dbo.vw_BookingDetails', N'V') IS NOT NULL
        DROP VIEW dbo.vw_BookingDetails;

    EXEC(N'CREATE VIEW dbo.vw_BookingDetails AS
SELECT
    b.BookingId,
    b.BookingDate,
    e.EventId,
    e.EventName,
    e.EventDate,
    e.Description   AS EventDescription,
    e.ImageUrl      AS EventImageUrl,
    e.EventTypeId   AS EventTypeId,
    t.Name          AS EventTypeName,
    v.VenueId,
    v.VenueName,
    v.Location      AS VenueLocation,
    v.Capacity      AS VenueCapacity,
    v.ImageUrl      AS VenueImageUrl,
    v.IsAvailable   AS VenueIsAvailable
FROM dbo.Bookings b
INNER JOIN dbo.Events e ON e.EventId = b.EventId
INNER JOIN dbo.Venues v ON v.VenueId = b.VenueId
LEFT JOIN dbo.EventTypes t ON t.EventTypeId = e.EventTypeId');
END"
        };
    }
}
