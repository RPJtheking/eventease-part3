using EventEase.Models;
using Microsoft.EntityFrameworkCore;

namespace EventEase.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Venue> Venues { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<Booking> Bookings { get; set; }

        // Part 3: lookup table of predefined event categories.
        public DbSet<EventType> EventTypes { get; set; }

        // Part 2: read-only projection over the "vw_BookingDetails" SQL view,
        // used to power the enhanced booking display and search.
        public DbSet<BookingDetailsView> BookingDetailsViews { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Event -> Venue (optional: an event can exist without a venue yet)
            modelBuilder.Entity<Event>()
                .HasOne(e => e.Venue)
                .WithMany(v => v.Events)
                .HasForeignKey(e => e.VenueId)
                .OnDelete(DeleteBehavior.SetNull);

            // Part 3: Event -> EventType (optional lookup; a type in use cannot be deleted)
            modelBuilder.Entity<EventType>()
                .HasIndex(t => t.Name)
                .IsUnique();

            modelBuilder.Entity<Event>()
                .HasOne(e => e.EventType)
                .WithMany(t => t.Events)
                .HasForeignKey(e => e.EventTypeId)
                .OnDelete(DeleteBehavior.Restrict);

            // Booking -> Event (restrict delete so an event with bookings cannot be removed)
            modelBuilder.Entity<Booking>()
                .HasOne(b => b.Event)
                .WithMany(e => e.Bookings)
                .HasForeignKey(b => b.EventId)
                .OnDelete(DeleteBehavior.Restrict);

            // Booking -> Venue (restrict delete so a venue with bookings cannot be removed)
            modelBuilder.Entity<Booking>()
                .HasOne(b => b.Venue)
                .WithMany(v => v.Bookings)
                .HasForeignKey(b => b.VenueId)
                .OnDelete(DeleteBehavior.Restrict);

            // Part 2 B: database-level safety net for double bookings - even if the
            // application-level check in BookingsController is ever bypassed (e.g. a
            // race condition between two specialists), the database itself rejects a
            // second booking for the same venue at the same date and time.
            modelBuilder.Entity<Booking>()
                .HasIndex(b => new { b.VenueId, b.BookingDate })
                .IsUnique()
                .HasDatabaseName("UX_Bookings_Venue_Date");

            // Keyless entity mapped to the database view created by the
            // AddBookingDetailsView migration. EF Core will never try to create a
            // table for this - it is purely a read model for queries.
            modelBuilder.Entity<BookingDetailsView>(entity =>
            {
                entity.HasNoKey();
                entity.ToView("vw_BookingDetails");
            });

            // Part 3: predefined event categories.
            modelBuilder.Entity<EventType>().HasData(
                new EventType { EventTypeId = 1, Name = "Wedding" },
                new EventType { EventTypeId = 2, Name = "Conference" },
                new EventType { EventTypeId = 3, Name = "Gala / Fundraiser" },
                new EventType { EventTypeId = 4, Name = "Corporate Function" },
                new EventType { EventTypeId = 5, Name = "Birthday / Celebration" },
                new EventType { EventTypeId = 6, Name = "Concert / Performance" },
                new EventType { EventTypeId = 7, Name = "Exhibition / Expo" },
                new EventType { EventTypeId = 8, Name = "Other" }
            );

            // Seed data so the app has something to show immediately after the first migration.
            modelBuilder.Entity<Venue>().HasData(
                new Venue { VenueId = 1, VenueName = "Riverside Hall", Location = "12 River Road, Pretoria", Capacity = 250, ImageUrl = "https://picsum.photos/seed/riverside/600/400" },
                new Venue { VenueId = 2, VenueName = "Garden Pavilion", Location = "45 Botanical Ave, Johannesburg", Capacity = 120, ImageUrl = "https://picsum.photos/seed/garden/600/400" },
                new Venue { VenueId = 3, VenueName = "Skyline Conference Centre", Location = "1 Corporate Blvd, Sandton", Capacity = 500, ImageUrl = "https://picsum.photos/seed/skyline/600/400" }
            );

            modelBuilder.Entity<Event>().HasData(
                new Event { EventId = 1, EventName = "Smith Wedding", EventDate = new DateTime(2026, 11, 14), Description = "Wedding reception for 150 guests.", VenueId = 2, EventTypeId = 1, ImageUrl = "https://picsum.photos/seed/wedding/600/400" },
                new Event { EventId = 2, EventName = "Annual Tech Conference", EventDate = new DateTime(2026, 10, 3), Description = "Two-day technology conference.", VenueId = 3, EventTypeId = 2, ImageUrl = "https://picsum.photos/seed/conference/600/400" },
                new Event { EventId = 3, EventName = "Charity Gala", EventDate = new DateTime(2027, 1, 20), Description = "Fundraising dinner, venue still to be confirmed.", VenueId = null, EventTypeId = 3, ImageUrl = "https://picsum.photos/seed/gala/600/400" }
            );

            modelBuilder.Entity<Booking>().HasData(
                new Booking { BookingId = 1, EventId = 1, VenueId = 2, BookingDate = new DateTime(2026, 9, 1) },
                new Booking { BookingId = 2, EventId = 2, VenueId = 3, BookingDate = new DateTime(2026, 9, 3) }
            );
        }
    }
}
