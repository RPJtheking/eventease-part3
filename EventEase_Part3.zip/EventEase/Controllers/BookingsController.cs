using EventEase.Data;
using EventEase.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace EventEase.Controllers
{
    public class BookingsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<BookingsController> _logger;

        public BookingsController(ApplicationDbContext context, ILogger<BookingsController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: Bookings
        // Part 2 C: backed by the vw_BookingDetails database view so booking
        // specialists get a richer display (venue + event info together), and can
        // search by BookingID or Event Name from a single box.
        public async Task<IActionResult> Index(string? searchString)
        {
            // Read the consolidated SQL view: Bookings + Events + Venues.
            // The view is created by the AddBookingDetailsView migration.
            var bookings = _context.BookingDetailsViews.AsNoTracking().AsQueryable();

            if (!string.IsNullOrWhiteSpace(searchString))
            {
                searchString = searchString.Trim();
                ViewData["CurrentFilter"] = searchString;

                // Part 2 requirement: search by BookingID OR Event Name.
                if (int.TryParse(searchString, out var bookingId))
                {
                    bookings = bookings.Where(b =>
                        b.BookingId == bookingId ||
                        EF.Functions.Like(b.EventName, $"%{searchString}%"));
                }
                else
                {
                    bookings = bookings.Where(b =>
                        EF.Functions.Like(b.EventName, $"%{searchString}%"));
                }
            }

            try
            {
                var results = await bookings
                    .OrderBy(b => b.BookingDate)
                    .ToListAsync();

                return View(results);
            }
            catch (Exception ex)
            {
                // Friendly handling if the SQL view was not deployed yet.
                _logger.LogError(ex, "Unable to load vw_BookingDetails.");
                TempData["Error"] = "The consolidated booking view is not available yet. Please apply the database migrations and reload the page.";
                return View(Array.Empty<BookingDetailsView>());
            }
        }

        // GET: Bookings/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var booking = await _context.Bookings
                .Include(b => b.Event)
                .Include(b => b.Venue)
                .FirstOrDefaultAsync(b => b.BookingId == id);

            if (booking == null) return NotFound();

            return View(booking);
        }

        // GET: Bookings/Create
        public IActionResult Create()
        {
            PopulateDropdowns();
            return View();
        }

        // POST: Bookings/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("EventId,VenueId,BookingDate")] Booking booking)
        {
            // Part 2 B: prevent double-booking a venue for two different events at
            // the same date AND time.
            bool alreadyBooked = await _context.Bookings.AnyAsync(b =>
                b.VenueId == booking.VenueId && b.BookingDate == booking.BookingDate);

            if (alreadyBooked)
            {
                ModelState.AddModelError(string.Empty, "This venue is already booked for another event at the selected date and time. Please choose another date/time or venue.");
                TempData["ValidationAlert"] = "This venue is already booked for another event at the selected date and time. Please choose another date/time or venue.";
            }

            // Part 3: venues flagged as unavailable cannot take new bookings.
            bool venueUnavailable = await _context.Venues.AnyAsync(v => v.VenueId == booking.VenueId && !v.IsAvailable);
            if (venueUnavailable)
            {
                const string msg = "This venue is currently marked as unavailable for booking. Please choose another venue.";
                ModelState.AddModelError(nameof(Booking.VenueId), msg);
                TempData["ValidationAlert"] = msg;
            }

            if (!ModelState.IsValid)
            {
                if (TempData["ValidationAlert"] == null)
                {
                    TempData["ValidationAlert"] = "Please fix the highlighted fields before saving this booking.";
                }
                PopulateDropdowns(booking.EventId, booking.VenueId);
                return View(booking);
            }

            try
            {
                _context.Add(booking);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Booking was created successfully.";
                return RedirectToAction(nameof(Index));
            }
            catch (DbUpdateException ex)
            {
                // Safety net: the database's own unique index (VenueId, BookingDate)
                // rejects this too, e.g. if two specialists submit at the same instant.
                _logger.LogWarning(ex, "Unique index rejected booking for event {EventId} at venue {VenueId}.", booking.EventId, booking.VenueId);
                ModelState.AddModelError(string.Empty, "This venue is already booked for another event at the selected date and time. Please choose another date/time or venue.");
                TempData["ValidationAlert"] = "This venue is already booked for another event at the selected date and time. Please choose another date/time or venue.";
                PopulateDropdowns(booking.EventId, booking.VenueId);
                return View(booking);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to create booking for event {EventId} at venue {VenueId}.", booking.EventId, booking.VenueId);
                ModelState.AddModelError(string.Empty, "Something went wrong while saving this booking. Please try again.");
                TempData["ValidationAlert"] = "Something went wrong while saving this booking. Please try again.";
                PopulateDropdowns(booking.EventId, booking.VenueId);
                return View(booking);
            }
        }

        // GET: Bookings/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var booking = await _context.Bookings.FindAsync(id);
            if (booking == null) return NotFound();

            PopulateDropdowns(booking.EventId, booking.VenueId);
            return View(booking);
        }

        // POST: Bookings/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BookingId,EventId,VenueId,BookingDate")] Booking booking)
        {
            if (id != booking.BookingId) return NotFound();

            bool alreadyBooked = await _context.Bookings.AnyAsync(b =>
                b.BookingId != booking.BookingId &&
                b.VenueId == booking.VenueId &&
                b.BookingDate == booking.BookingDate);

            if (alreadyBooked)
            {
                ModelState.AddModelError(string.Empty, "This venue is already booked for another event at the selected date and time. Please choose another date/time or venue.");
                TempData["ValidationAlert"] = "This venue is already booked for another event at the selected date and time. Please choose another date/time or venue.";
            }

            if (!ModelState.IsValid)
            {
                if (TempData["ValidationAlert"] == null)
                {
                    TempData["ValidationAlert"] = "Please fix the highlighted fields before saving this booking.";
                }
                PopulateDropdowns(booking.EventId, booking.VenueId);
                return View(booking);
            }

            try
            {
                _context.Update(booking);
                await _context.SaveChangesAsync();
                TempData["Success"] = "Booking was updated successfully.";
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BookingExists(booking.BookingId)) return NotFound();
                _logger.LogWarning("Concurrency conflict updating booking {BookingId}.", booking.BookingId);
                ModelState.AddModelError(string.Empty, "This booking was updated by someone else. Please reload and try again.");
                TempData["ValidationAlert"] = "This booking was updated by someone else. Please reload and try again.";
                PopulateDropdowns(booking.EventId, booking.VenueId);
                return View(booking);
            }
            catch (DbUpdateException ex)
            {
                _logger.LogWarning(ex, "Unique index rejected updated booking {BookingId}.", booking.BookingId);
                ModelState.AddModelError(string.Empty, "This venue is already booked for another event at the selected date and time. Please choose another date/time or venue.");
                TempData["ValidationAlert"] = "This venue is already booked for another event at the selected date and time. Please choose another date/time or venue.";
                PopulateDropdowns(booking.EventId, booking.VenueId);
                return View(booking);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to update booking {BookingId}.", booking.BookingId);
                ModelState.AddModelError(string.Empty, "Something went wrong while saving this booking. Please try again.");
                TempData["ValidationAlert"] = "Something went wrong while saving this booking. Please try again.";
                PopulateDropdowns(booking.EventId, booking.VenueId);
                return View(booking);
            }

            return RedirectToAction(nameof(Index));
        }

        // GET: Bookings/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var booking = await _context.Bookings
                .Include(b => b.Event)
                .Include(b => b.Venue)
                .FirstOrDefaultAsync(b => b.BookingId == id);

            if (booking == null) return NotFound();

            return View(booking);
        }

        // POST: Bookings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                var booking = await _context.Bookings.FindAsync(id);
                if (booking != null)
                {
                    _context.Bookings.Remove(booking);
                    await _context.SaveChangesAsync();
                    TempData["Success"] = "Booking was cancelled.";
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to cancel booking {BookingId}.", id);
                TempData["Error"] = "This booking could not be cancelled. Please try again.";
            }

            return RedirectToAction(nameof(Index));
        }

        private bool BookingExists(int id)
        {
            return _context.Bookings.Any(e => e.BookingId == id);
        }

        private void PopulateDropdowns(int? selectedEventId = null, int? selectedVenueId = null)
        {
            ViewData["EventId"] = new SelectList(_context.Events.OrderBy(e => e.EventName), "EventId", "EventName", selectedEventId);
            ViewData["VenueId"] = new SelectList(_context.Venues.OrderBy(v => v.VenueName), "VenueId", "VenueName", selectedVenueId);
        }
    }
}
