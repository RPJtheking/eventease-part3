using EventEase.Data;
using EventEase.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace EventEase.Controllers
{
    /// <summary>
    /// Backs the search bar shown in the navigation bar on every page, letting
    /// booking specialists find a Venue, Event, or Booking from one place.
    /// Part 3: results can be narrowed by event type, date range and venue
    /// availability. The keyword is optional - filters alone are enough to search.
    /// </summary>
    public class SearchController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<SearchController> _logger;

        public SearchController(ApplicationDbContext context, ILogger<SearchController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: /Search?query=...&eventTypeId=...&dateFrom=...&dateTo=...&availability=...
        public async Task<IActionResult> Index(
            string? query,
            int? eventTypeId,
            DateTime? dateFrom,
            DateTime? dateTo,
            string? availability)
        {
            // Be forgiving if the dates were entered the wrong way round.
            if (dateFrom.HasValue && dateTo.HasValue && dateFrom > dateTo)
            {
                (dateFrom, dateTo) = (dateTo, dateFrom);
                TempData["Error"] = "The start date was after the end date, so the two dates were swapped.";
            }

            availability = availability?.Trim().ToLowerInvariant();
            if (availability != "available" && availability != "unavailable")
            {
                availability = null;
            }

            var results = new SearchResultsViewModel
            {
                Query = query,
                EventTypeId = eventTypeId,
                DateFrom = dateFrom?.Date,
                DateTo = dateTo?.Date,
                Availability = availability
            };

            try
            {
                results.EventTypes = await _context.EventTypes
                    .AsNoTracking()
                    .OrderBy(t => t.Name)
                    .Select(t => new SelectListItem(t.Name, t.EventTypeId.ToString(), t.EventTypeId == eventTypeId))
                    .ToListAsync();
            }
            catch (Exception ex)
            {
                // E.g. the Part 3 migration has not been applied yet.
                _logger.LogError(ex, "Unable to load event types for the search filters.");
                TempData["Error"] = "The search filters are unavailable right now. Please try again.";
            }

            if (!results.HasSearched)
            {
                return View(results);
            }

            var term = query?.Trim();
            var hasTerm = !string.IsNullOrEmpty(term);

            // Inclusive date range: DateTo covers the whole of that day.
            DateTime? rangeStart = results.DateFrom;
            DateTime? rangeEnd = results.DateTo?.AddDays(1);

            try
            {
                // ---------- Venues ----------
                var venues = _context.Venues.AsNoTracking().AsQueryable();

                if (hasTerm)
                {
                    venues = venues.Where(v => v.VenueName.Contains(term!) || v.Location.Contains(term!));
                }

                if (eventTypeId.HasValue)
                {
                    // Venues that host (or are hosting) events of the chosen type.
                    venues = venues.Where(v => v.Events!.Any(e => e.EventTypeId == eventTypeId));
                }

                if (availability != null)
                {
                    var matchingVenueIds = await VenueIdsByAvailabilityAsync(availability, rangeStart, rangeEnd);
                    venues = venues.Where(v => matchingVenueIds.Contains(v.VenueId));
                }

                results.Venues = await venues.OrderBy(v => v.VenueName).ToListAsync();

                // ---------- Events ----------
                var events = _context.Events.AsNoTracking()
                    .Include(e => e.Venue)
                    .Include(e => e.EventType)
                    .AsQueryable();

                if (hasTerm)
                {
                    events = events.Where(e => e.EventName.Contains(term!) || (e.Description != null && e.Description.Contains(term!)));
                }

                if (eventTypeId.HasValue)
                {
                    events = events.Where(e => e.EventTypeId == eventTypeId);
                }

                if (rangeStart.HasValue)
                {
                    events = events.Where(e => e.EventDate >= rangeStart.Value);
                }

                if (rangeEnd.HasValue)
                {
                    events = events.Where(e => e.EventDate < rangeEnd.Value);
                }

                if (availability != null)
                {
                    // Events at a venue that matches the availability filter; events with
                    // no venue yet can't be judged, so they are left out.
                    var matchingVenueIds = await VenueIdsByAvailabilityAsync(availability, rangeStart, rangeEnd);
                    events = events.Where(e => e.VenueId != null && matchingVenueIds.Contains(e.VenueId.Value));
                }

                results.Events = await events.OrderBy(e => e.EventDate).ToListAsync();

                // ---------- Bookings (via the vw_BookingDetails view) ----------
                var bookings = _context.BookingDetailsViews.AsNoTracking().AsQueryable();

                if (hasTerm)
                {
                    bookings = int.TryParse(term, out int bookingId)
                        ? bookings.Where(b => b.BookingId == bookingId || b.EventName.Contains(term!) || b.VenueName.Contains(term!))
                        : bookings.Where(b => b.EventName.Contains(term!) || b.VenueName.Contains(term!));
                }

                if (eventTypeId.HasValue)
                {
                    bookings = bookings.Where(b => b.EventTypeId == eventTypeId);
                }

                if (rangeStart.HasValue)
                {
                    bookings = bookings.Where(b => b.EventDate >= rangeStart.Value);
                }

                if (rangeEnd.HasValue)
                {
                    bookings = bookings.Where(b => b.EventDate < rangeEnd.Value);
                }

                if (availability != null)
                {
                    var matchingVenueIds = await VenueIdsByAvailabilityAsync(availability, rangeStart, rangeEnd);
                    bookings = bookings.Where(b => matchingVenueIds.Contains(b.VenueId));
                }

                results.Bookings = await bookings.OrderBy(b => b.BookingDate).ToListAsync();
            }
            catch (Exception ex)
            {
                // Keeps a search typo or a temporary database hiccup from
                // crashing the page - the user just sees "no results" instead.
                _logger.LogError(ex, "Search failed for query '{Query}'.", term);
                TempData["Error"] = "We couldn't complete that search right now. Please try again.";
            }

            return View(results);
        }

        /// <summary>
        /// A venue counts as "available" when it is flagged available AND (if a date
        /// range was chosen) has no booking falling inside that range. "Unavailable"
        /// is the exact opposite. Returns venue ids so the Venue, Event and Booking
        /// queries can all share one definition of availability.
        /// </summary>
        private async Task<List<int>> VenueIdsByAvailabilityAsync(string availability, DateTime? rangeStart, DateTime? rangeEnd)
        {
            var hasRange = rangeStart.HasValue || rangeEnd.HasValue;

            var bookedInRange = hasRange
                ? _context.Bookings
                    .Where(b => (rangeStart == null || b.BookingDate >= rangeStart) && (rangeEnd == null || b.BookingDate < rangeEnd))
                    .Select(b => b.VenueId)
                : _context.Bookings.Where(b => false).Select(b => b.VenueId);

            var venues = _context.Venues.AsNoTracking();

            venues = availability == "available"
                ? venues.Where(v => v.IsAvailable && !bookedInRange.Contains(v.VenueId))
                : venues.Where(v => !v.IsAvailable || bookedInRange.Contains(v.VenueId));

            return await venues.Select(v => v.VenueId).ToListAsync();
        }
    }
}
