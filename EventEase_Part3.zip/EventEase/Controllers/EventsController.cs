using EventEase.Data;
using EventEase.Models;
using EventEase.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace EventEase.Controllers
{
    public class EventsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IBlobStorageService _blobStorageService;
        private readonly ILogger<EventsController> _logger;

        public EventsController(ApplicationDbContext context, IBlobStorageService blobStorageService, ILogger<EventsController> logger)
        {
            _context = context;
            _blobStorageService = blobStorageService;
            _logger = logger;
        }

        // GET: Events
        public async Task<IActionResult> Index(string? searchString, int? eventTypeId)
        {
            try
            {
                var events = _context.Events.Include(e => e.Venue).Include(e => e.EventType).AsQueryable();

                // Part 3: quick filter by event type on the Events list as well.
                if (eventTypeId.HasValue)
                {
                    events = events.Where(e => e.EventTypeId == eventTypeId);
                }

                if (!string.IsNullOrWhiteSpace(searchString))
                {
                    events = events.Where(e =>
                        e.EventName.Contains(searchString) ||
                        (e.Description != null && e.Description.Contains(searchString)));
                    ViewData["CurrentFilter"] = searchString;
                }

                var types = await _context.EventTypes.AsNoTracking().OrderBy(t => t.Name).ToListAsync();
                ViewData["EventTypeFilter"] = new SelectList(types, "EventTypeId", "Name", eventTypeId);

                return View(await events.OrderBy(e => e.EventDate).ToListAsync());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to load the events list: {Message}", ex.GetBaseException().Message);
                TempData["Error"] = "We couldn't load the events. The database may need updating (run 'dotnet ef database update').";
                ViewData["EventTypeFilter"] = new SelectList(Enumerable.Empty<EventType>(), "EventTypeId", "Name");
                return View(new List<Event>());
            }
        }

        // GET: Events/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var @event = await _context.Events
                .Include(e => e.Venue)
                .Include(e => e.EventType)
                .Include(e => e.Bookings)
                .FirstOrDefaultAsync(e => e.EventId == id);

            if (@event == null) return NotFound();

            return View(@event);
        }

        // GET: Events/Create
        public IActionResult Create()
        {
            PopulateDropdowns(null, null);
            return View();
        }

        // POST: Events/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("EventName,EventDate,Description,VenueId,EventTypeId,ImageFile")] Event @event)
        {
            if (@event.ImageFile == null || @event.ImageFile.Length == 0)
            {
                ModelState.AddModelError(nameof(Event.ImageFile), "Please choose an image for the event.");
            }

            if (!ModelState.IsValid)
            {
                TempData["ValidationAlert"] = "Please fix the highlighted fields before saving this event.";
                PopulateDropdowns(@event.VenueId, @event.EventTypeId);
                return View(@event);
            }

            try
            {
                @event.ImageUrl = await _blobStorageService.UploadImageAsync(@event.ImageFile!);

                _context.Add(@event);
                await _context.SaveChangesAsync();
                TempData["Success"] = $"Event \"{@event.EventName}\" was created successfully.";
                return RedirectToAction(nameof(Index));
            }
            catch (ArgumentException ex)
            {
                ModelState.AddModelError(nameof(Event.ImageFile), ex.Message);
                TempData["ValidationAlert"] = ex.Message;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to create event {EventName}.", @event.EventName);
                ModelState.AddModelError(string.Empty, "Something went wrong while saving this event. Please try again.");
                TempData["ValidationAlert"] = "Something went wrong while saving this event. Please try again.";
            }

            PopulateDropdowns(@event.VenueId, @event.EventTypeId);
            return View(@event);
        }

        // GET: Events/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var @event = await _context.Events.FindAsync(id);
            if (@event == null) return NotFound();

            PopulateDropdowns(@event.VenueId, @event.EventTypeId);
            return View(@event);
        }

        // POST: Events/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("EventId,EventName,EventDate,Description,VenueId,EventTypeId,ImageUrl,ImageFile")] Event @event)
        {
            if (id != @event.EventId) return NotFound();

            if (!ModelState.IsValid)
            {
                TempData["ValidationAlert"] = "Please fix the highlighted fields before saving this event.";
                PopulateDropdowns(@event.VenueId, @event.EventTypeId);
                return View(@event);
            }

            try
            {
                if (@event.ImageFile != null && @event.ImageFile.Length > 0)
                {
                    var oldImageUrl = @event.ImageUrl;
                    @event.ImageUrl = await _blobStorageService.UploadImageAsync(@event.ImageFile);
                    await _blobStorageService.DeleteImageAsync(oldImageUrl);
                }

                _context.Update(@event);
                await _context.SaveChangesAsync();
                TempData["Success"] = $"Event \"{@event.EventName}\" was updated successfully.";
                return RedirectToAction(nameof(Index));
            }
            catch (ArgumentException ex)
            {
                ModelState.AddModelError(nameof(Event.ImageFile), ex.Message);
                TempData["ValidationAlert"] = ex.Message;
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EventExists(@event.EventId)) return NotFound();
                _logger.LogWarning("Concurrency conflict updating event {EventId}.", @event.EventId);
                ModelState.AddModelError(string.Empty, "This event was updated by someone else. Please reload and try again.");
                TempData["ValidationAlert"] = "This event was updated by someone else. Please reload and try again.";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to update event {EventId}.", @event.EventId);
                ModelState.AddModelError(string.Empty, "Something went wrong while saving this event. Please try again.");
                TempData["ValidationAlert"] = "Something went wrong while saving this event. Please try again.";
            }

            PopulateDropdowns(@event.VenueId, @event.EventTypeId);
            return View(@event);
        }

        // GET: Events/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var @event = await _context.Events
                .Include(e => e.Venue)
                .Include(e => e.Bookings)
                .FirstOrDefaultAsync(e => e.EventId == id);

            if (@event == null) return NotFound();

            ViewData["HasActiveBookings"] = @event.Bookings != null && @event.Bookings.Any();

            return View(@event);
        }

        // POST: Events/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var @event = await _context.Events
                .Include(e => e.Bookings)
                .FirstOrDefaultAsync(e => e.EventId == id);

            if (@event == null) return RedirectToAction(nameof(Index));

            // Restrict deletion of events associated with existing bookings.
            if (@event.Bookings != null && @event.Bookings.Any())
            {
                TempData["Error"] = $"\"{@event.EventName}\" cannot be deleted because it has {@event.Bookings.Count} existing booking(s). Please cancel those bookings first.";
                return RedirectToAction(nameof(Delete), new { id });
            }

            try
            {
                _context.Events.Remove(@event);
                await _context.SaveChangesAsync();
                await _blobStorageService.DeleteImageAsync(@event.ImageUrl);
                TempData["Success"] = $"Event \"{@event.EventName}\" was deleted.";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to delete event {EventId}.", id);
                TempData["Error"] = "This event could not be deleted. Please try again.";
            }

            return RedirectToAction(nameof(Index));
        }

        // Part 3: fills the Venue and Event Type drop-downs on the Create/Edit forms.
        private void PopulateDropdowns(int? selectedVenueId, int? selectedEventTypeId)
        {
            ViewData["VenueId"] = new SelectList(_context.Venues.OrderBy(v => v.VenueName), "VenueId", "VenueName", selectedVenueId);
            ViewData["EventTypeId"] = new SelectList(_context.EventTypes.OrderBy(t => t.Name), "EventTypeId", "Name", selectedEventTypeId);
        }

        private bool EventExists(int id)
        {
            return _context.Events.Any(e => e.EventId == id);
        }
    }
}
