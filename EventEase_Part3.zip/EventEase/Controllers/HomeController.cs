using System.Diagnostics;
using EventEase.Data;
using EventEase.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventEase.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HomeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            ViewData["VenueCount"] = await _context.Venues.CountAsync();
            ViewData["EventCount"] = await _context.Events.CountAsync();
            ViewData["BookingCount"] = await _context.Bookings.CountAsync();
            return View();
        }

        // Part 2 B: friendly landing spot for both the global exception handler
        // (unhandled exceptions) and UseStatusCodePagesWithReExecute (404s, etc.),
        // so the user always sees a readable page instead of a raw error.
        [Route("/Home/Error")]
        public IActionResult Error(int? statusCode = null)
        {
            var model = new ErrorViewModel
            {
                RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier,
                StatusCode = statusCode
            };
            return View(model);
        }
    }
}
