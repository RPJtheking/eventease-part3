using EventEase.Data;
using EventEase.Models;
using EventEase.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventEase.Controllers
{
    public class VenuesController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IBlobStorageService _blobStorageService;
        private readonly ILogger<VenuesController> _logger;

        public VenuesController(ApplicationDbContext context, IBlobStorageService blobStorageService, ILogger<VenuesController> logger)
        {
            _context = context;
            _blobStorageService = blobStorageService;
            _logger = logger;
        }

        // GET: Venues
        public async Task<IActionResult> Index(string? searchString, string? availability)
        {
            ViewData["AvailabilityFilter"] = availability;

            try
            {
                var venues = _context.Venues.AsQueryable();

                // Part 3: filter by the availability flag.
                if (availability == "available")
                {
                    venues = venues.Where(v => v.IsAvailable);
                }
                else if (availability == "unavailable")
                {
                    venues = venues.Where(v => !v.IsAvailable);
                }

                if (!string.IsNullOrWhiteSpace(searchString))
                {
                    venues = venues.Where(v =>
                        v.VenueName.Contains(searchString) ||
                        v.Location.Contains(searchString));
                    ViewData["CurrentFilter"] = searchString;
                }

                return View(await venues.OrderBy(v => v.VenueName).ToListAsync());
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to load the venues list: {Message}", ex.GetBaseException().Message);
                TempData["Error"] = "We couldn't load the venues. The database may need updating (run 'dotnet ef database update').";
                return View(new List<Venue>());
            }
        }

        // GET: Venues/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var venue = await _context.Venues
                .Include(v => v.Events)
                .Include(v => v.Bookings)
                .FirstOrDefaultAsync(v => v.VenueId == id);

            if (venue == null) return NotFound();

            return View(venue);
        }

        // GET: Venues/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Venues/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("VenueName,Location,Capacity,IsAvailable,ImageFile")] Venue venue)
        {
            // Error handling & validation (Part 2 B): a photo is required for a new
            // venue, but we validate it ourselves since IFormFile can't carry a
            // [Required] data annotation message cleanly.
            if (venue.ImageFile == null || venue.ImageFile.Length == 0)
            {
                ModelState.AddModelError(nameof(Venue.ImageFile), "Please choose an image for the venue.");
            }

            if (!ModelState.IsValid)
            {
                TempData["ValidationAlert"] = "Please fix the highlighted fields before saving this venue.";
                return View(venue);
            }

            try
            {
                venue.ImageUrl = await _blobStorageService.UploadImageAsync(venue.ImageFile!);

                _context.Add(venue);
                await _context.SaveChangesAsync();
                TempData["Success"] = $"Venue \"{venue.VenueName}\" was created successfully.";
                return RedirectToAction(nameof(Index));
            }
            catch (ArgumentException ex)
            {
                // Thrown by the blob service for user-fixable problems (bad file type/size).
                ModelState.AddModelError(nameof(Venue.ImageFile), ex.Message);
                TempData["ValidationAlert"] = ex.Message;
                return View(venue);
            }
            catch (Exception ex)
            {
                // Catch-all so an image-upload or database hiccup never crashes the app -
                // the user simply sees a friendly message and can try again.
                _logger.LogError(ex, "Failed to create venue {VenueName}.", venue.VenueName);
                ModelState.AddModelError(string.Empty, "Something went wrong while saving this venue. Please try again.");
                TempData["ValidationAlert"] = "Something went wrong while saving this venue. Please try again.";
                return View(venue);
            }
        }

        // GET: Venues/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var venue = await _context.Venues.FindAsync(id);
            if (venue == null) return NotFound();

            return View(venue);
        }

        // POST: Venues/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("VenueId,VenueName,Location,Capacity,IsAvailable,ImageUrl,ImageFile")] Venue venue)
        {
            if (id != venue.VenueId) return NotFound();

            if (!ModelState.IsValid)
            {
                TempData["ValidationAlert"] = "Please fix the highlighted fields before saving this venue.";
                return View(venue);
            }

            try
            {
                // Only touch Azure Storage if the specialist actually chose a new file -
                // otherwise keep the existing image URL untouched.
                if (venue.ImageFile != null && venue.ImageFile.Length > 0)
                {
                    var oldImageUrl = venue.ImageUrl;
                    venue.ImageUrl = await _blobStorageService.UploadImageAsync(venue.ImageFile);
                    await _blobStorageService.DeleteImageAsync(oldImageUrl);
                }

                _context.Update(venue);
                await _context.SaveChangesAsync();
                TempData["Success"] = $"Venue \"{venue.VenueName}\" was updated successfully.";
                return RedirectToAction(nameof(Index));
            }
            catch (ArgumentException ex)
            {
                ModelState.AddModelError(nameof(Venue.ImageFile), ex.Message);
                TempData["ValidationAlert"] = ex.Message;
                return View(venue);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!VenueExists(venue.VenueId)) return NotFound();
                _logger.LogWarning("Concurrency conflict updating venue {VenueId}.", venue.VenueId);
                ModelState.AddModelError(string.Empty, "This venue was updated by someone else. Please reload and try again.");
                TempData["ValidationAlert"] = "This venue was updated by someone else. Please reload and try again.";
                return View(venue);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to update venue {VenueId}.", venue.VenueId);
                ModelState.AddModelError(string.Empty, "Something went wrong while saving this venue. Please try again.");
                TempData["ValidationAlert"] = "Something went wrong while saving this venue. Please try again.";
                return View(venue);
            }
        }

        // GET: Venues/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var venue = await _context.Venues
                .Include(v => v.Bookings)
                .Include(v => v.Events)
                .FirstOrDefaultAsync(v => v.VenueId == id);

            if (venue == null) return NotFound();

            // Warn the booking specialist up-front if this venue has existing bookings.
            ViewData["HasActiveBookings"] = venue.Bookings != null && venue.Bookings.Any();

            return View(venue);
        }

        // POST: Venues/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var venue = await _context.Venues
                .Include(v => v.Bookings)
                .FirstOrDefaultAsync(v => v.VenueId == id);

            if (venue == null) return RedirectToAction(nameof(Index));

            // Restrict deletion of venues associated with existing bookings.
            if (venue.Bookings != null && venue.Bookings.Any())
            {
                TempData["Error"] = $"\"{venue.VenueName}\" cannot be deleted because it has {venue.Bookings.Count} existing booking(s). Please cancel those bookings first.";
                return RedirectToAction(nameof(Delete), new { id });
            }

            try
            {
                _context.Venues.Remove(venue);
                await _context.SaveChangesAsync();
                await _blobStorageService.DeleteImageAsync(venue.ImageUrl);
                TempData["Success"] = $"Venue \"{venue.VenueName}\" was deleted.";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to delete venue {VenueId}.", id);
                TempData["Error"] = "This venue could not be deleted. Please try again.";
            }

            return RedirectToAction(nameof(Index));
        }

        private bool VenueExists(int id)
        {
            return _context.Venues.Any(e => e.VenueId == id);
        }
    }
}
