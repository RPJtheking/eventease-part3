/* EventEase Part 3 - EventTypes lookup, Venue availability and refreshed booking view.
   Equivalent to the AddEventTypeAndVenueAvailability EF Core migration.
   Run against the same SQL Server / Azure SQL database used by the app.
   Safe to re-run: every step checks whether it has already been applied.
   NOTE: if you apply this script manually, ALSO run `dotnet ef database update`
   (or insert the migration row below) so EF doesn't try to apply it a second time. */

-- 1. EventTypes lookup table
IF OBJECT_ID('dbo.EventTypes', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.EventTypes (
        EventTypeId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_EventTypes PRIMARY KEY,
        Name        NVARCHAR(100) NOT NULL
    );
    CREATE UNIQUE INDEX IX_EventTypes_Name ON dbo.EventTypes (Name);
END
GO

-- 2. Predefined categories
SET IDENTITY_INSERT dbo.EventTypes ON;
INSERT INTO dbo.EventTypes (EventTypeId, Name)
SELECT v.EventTypeId, v.Name
FROM (VALUES
    (1, N'Wedding'), (2, N'Conference'), (3, N'Gala / Fundraiser'), (4, N'Corporate Function'),
    (5, N'Birthday / Celebration'), (6, N'Concert / Performance'), (7, N'Exhibition / Expo'), (8, N'Other')
) AS v(EventTypeId, Name)
WHERE NOT EXISTS (SELECT 1 FROM dbo.EventTypes t WHERE t.EventTypeId = v.EventTypeId);
SET IDENTITY_INSERT dbo.EventTypes OFF;
GO

-- 3. Availability field on Venues (existing venues default to available)
IF COL_LENGTH('dbo.Venues', 'IsAvailable') IS NULL
    ALTER TABLE dbo.Venues ADD IsAvailable BIT NOT NULL CONSTRAINT DF_Venues_IsAvailable DEFAULT 1;
GO

-- 4. Event type on Events (optional foreign key)
IF COL_LENGTH('dbo.Events', 'EventTypeId') IS NULL
BEGIN
    ALTER TABLE dbo.Events ADD EventTypeId INT NULL;
    CREATE INDEX IX_Events_EventTypeId ON dbo.Events (EventTypeId);
    ALTER TABLE dbo.Events ADD CONSTRAINT FK_Events_EventTypes_EventTypeId
        FOREIGN KEY (EventTypeId) REFERENCES dbo.EventTypes (EventTypeId);
END
GO

-- Classify the three seeded events
UPDATE dbo.Events SET EventTypeId = 1 WHERE EventId = 1 AND EventTypeId IS NULL;
UPDATE dbo.Events SET EventTypeId = 2 WHERE EventId = 2 AND EventTypeId IS NULL;
UPDATE dbo.Events SET EventTypeId = 3 WHERE EventId = 3 AND EventTypeId IS NULL;
GO

-- 5. Rebuild the consolidated view with event type + venue availability
IF OBJECT_ID('dbo.vw_BookingDetails', 'V') IS NOT NULL
    DROP VIEW dbo.vw_BookingDetails;
GO

CREATE VIEW dbo.vw_BookingDetails AS
SELECT
    b.BookingId,
    b.BookingDate,
    e.EventId,
    e.EventName,
    e.EventDate,
    e.Description AS EventDescription,
    e.ImageUrl    AS EventImageUrl,
    e.EventTypeId AS EventTypeId,
    t.Name        AS EventTypeName,
    v.VenueId,
    v.VenueName,
    v.Location    AS VenueLocation,
    v.Capacity    AS VenueCapacity,
    v.ImageUrl    AS VenueImageUrl,
    v.IsAvailable AS VenueIsAvailable
FROM dbo.Bookings AS b
INNER JOIN dbo.Events AS e ON e.EventId = b.EventId
INNER JOIN dbo.Venues AS v ON v.VenueId = b.VenueId
LEFT JOIN  dbo.EventTypes AS t ON t.EventTypeId = e.EventTypeId;
GO

-- 6. Tell EF Core this migration is already applied (only needed when running this script by hand)
IF OBJECT_ID('dbo.__EFMigrationsHistory', 'U') IS NOT NULL
   AND NOT EXISTS (SELECT 1 FROM dbo.__EFMigrationsHistory WHERE MigrationId = N'20260930100000_AddEventTypeAndVenueAvailability')
    INSERT INTO dbo.__EFMigrationsHistory (MigrationId, ProductVersion)
    VALUES (N'20260930100000_AddEventTypeAndVenueAvailability', N'8.0.8');
GO

SELECT * FROM dbo.vw_BookingDetails ORDER BY BookingDate;
