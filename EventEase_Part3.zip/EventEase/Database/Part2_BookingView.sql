/* EventEase Part 2 - Consolidated Bookings View
   Run against the same SQL Server / Azure SQL database configured in appsettings.json. */

IF OBJECT_ID('dbo.vw_BookingDetails', 'V') IS NOT NULL
    DROP VIEW dbo.vw_BookingDetails;
GO

CREATE VIEW dbo.vw_BookingDetails AS
SELECT
    b.BookingId,
    b.BookingDate,
    e.EventId,
    e.EventName,
    e.EventDate,
    e.Description AS EventDescription,
    e.ImageUrl AS EventImageUrl,
    v.VenueId,
    v.VenueName,
    v.Location AS VenueLocation,
    v.Capacity AS VenueCapacity,
    v.ImageUrl AS VenueImageUrl
FROM dbo.Bookings AS b
INNER JOIN dbo.Events AS e ON e.EventId = b.EventId
INNER JOIN dbo.Venues AS v ON v.VenueId = b.VenueId;
GO

SELECT * FROM dbo.vw_BookingDetails ORDER BY BookingDate;
