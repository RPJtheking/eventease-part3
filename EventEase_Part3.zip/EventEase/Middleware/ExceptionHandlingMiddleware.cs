namespace EventEase.Middleware
{
    /// <summary>
    /// Part 2 B: a last line of defence so that any unhandled exception anywhere in
    /// the pipeline is logged and turned into a friendly redirect to /Home/Error,
    /// instead of the request (and the user's session) simply crashing.
    /// Controller actions still handle their own expected errors (validation,
    /// concurrency, blob upload failures) - this middleware only catches whatever
    /// slips through.
    /// </summary>
    public class ExceptionHandlingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<ExceptionHandlingMiddleware> _logger;
        private readonly IHostEnvironment _environment;

        public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger, IHostEnvironment environment)
        {
            _next = next;
            _logger = logger;
            _environment = environment;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unhandled exception processing {Method} {Path}.", context.Request.Method, context.Request.Path);

                // While developing, let the framework's developer exception page show the
                // real error (stack trace and message) instead of the friendly page.
                if (_environment.IsDevelopment())
                {
                    throw;
                }

                if (!context.Response.HasStarted)
                {
                    context.Response.Redirect("/Home/Error");
                }
            }
        }
    }
}
