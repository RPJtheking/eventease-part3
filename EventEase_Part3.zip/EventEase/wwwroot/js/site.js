// Part 2 B requirement: "add a function that displays an alert to the user
// when a validation error occurs." This is invoked from _Layout.cshtml
// whenever the server round-trips a validation problem via TempData.
function showValidationAlert(message) {
    if (!message) {
        return;
    }
    window.alert(message);
}

// Client-side confirmation on destructive actions (delete/cancel), so a
// misclick can never silently remove data.
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('form[data-confirm]').forEach(function (form) {
        form.addEventListener('submit', function (event) {
            var message = form.getAttribute('data-confirm') || 'Are you sure?';
            if (!window.confirm(message)) {
                event.preventDefault();
            }
        });
    });
});
