# EventEase — Reflection on the Project and Cloud Skills Developed

> Draft written from the project history. Please edit it so it reflects your own experience and wording.

## The project
EventEase began in Part 1 as an ASP.NET Core MVC app on Azure App Service with Azure SQL, managing Venues, Events
and Bookings. In Part 2 I added Azure Blob Storage for images, error handling (including double-booking prevention
enforced both in code and by a unique database index), and a consolidated `vw_BookingDetails` view with search.
In Part 3 I extended the search with an `EventTypes` lookup, a venue availability field and filters by event type,
date range and availability, then updated the Azure SQL schema and redeployed.

## Cloud skills developed
- **Platform services:** deploying to App Service, provisioning and securing Azure SQL, and using Blob Storage from code.
- **Data design:** normalised tables and lookups, foreign keys, indexes and views, and using EF Core migrations so the
  cloud database changes in a controlled, repeatable way.
- **Configuration and security:** keeping connection strings out of source control via app settings/user secrets,
  and understanding firewalls and least-privilege access.
- **Resilience:** layered validation, try/catch handling, exception middleware and database constraints so that bad
  input or a race condition degrades gracefully.
- **Architecture thinking:** comparing SQL with Cosmos DB, and seeing how Event Grid and Logic Apps could add
  event-driven automation.

## Challenges and lessons
- *Deployment order matters* — code that references a new column fails if the database hasn't been updated first, so
  schema changes and publishing must be sequenced (migration first, then publish).
- *Translating queries to SQL* — filters must use constructs EF Core can translate; I composed availability from
  venue-id lists rather than custom C# methods.
- *Small design choices compound* — making `EventTypeId` nullable and defaulting `IsAvailable` to true meant existing
  data stayed valid with no manual clean-up.
- *Documenting as you go* saved time at deployment and made the work easier to verify.

## What I would do next
Add CRUD screens for event types, move notifications to an Event Grid + Logic Apps workflow, introduce Azure AI Search
for typo-tolerant search, add authentication and role-based access, set up CI/CD with GitHub Actions, and use
Application Insights for monitoring.
