# EventEase — Part 2 Theory Answers

## 1. Azure Cognitive Search vs. traditional search engines

**How it differs.** A traditional search implementation over a relational
database — like the `Contains()` filters used in this project's
`Bookings`/`Events`/`Venues` search boxes — translates directly into a SQL
`LIKE '%term%'` query. It matches only exact substrings, has no understanding
of meaning, synonyms, or relevance ranking, and typically requires a full
table scan (or at best a basic index) as the dataset grows. Azure Cognitive
Search (now branded *Azure AI Search*) is a managed search-as-a-service
product built around an **inverted index**, the same underlying data
structure used by engines like Elasticsearch or Lucene. Content from one or
more data sources (Azure SQL, Cosmos DB, Blob Storage, etc.) is pulled
through an **indexer**, optionally enriched by an **AI skillset** (OCR on
scanned images, key-phrase extraction, entity recognition, image tagging,
language detection), and stored as a searchable index. Queries against that
index support full-text relevance scoring (BM25), fuzzy matching, filters,
facets, autocomplete/suggestions, and semantic ranking — capabilities a
plain SQL `WHERE` clause cannot offer without significant custom
engineering.

**Where it offers a clear advantage.** For EventEase specifically, Cognitive
Search would shine if the catalogue of venues and events grew large and
users needed to search across unstructured content — e.g., finding a venue
by describing it ("outdoor garden venue near Johannesburg with parking") or
searching the *text extracted from event flyer images* uploaded to Blob
Storage. It's also the natural choice for faceted browsing (filter by
capacity range, location, date, tag) and for typo-tolerant search ("weding"
still finds "wedding"). More broadly, Cognitive Search offers a clear
advantage in scenarios like e-commerce product catalogues, document/knowledge
repositories, and any application that needs to search across a mix of
structured metadata and unstructured content (PDFs, images, Office
documents) at scale.

**Limitations and mitigations.**
- *Cost and operational overhead*: it is a separate billed Azure resource
  with its own pricing tier, and running indexers/skillsets against AI
  Enrichment can incur additional cognitive-services costs. This can be
  mitigated by choosing an appropriately small pricing tier for course/demo
  workloads, or by only enabling AI enrichment on the specific fields that
  need it rather than the whole index.
- *Indexing latency*: content is not searchable the instant it's written to
  the source database — the indexer runs on a schedule (or must be triggered
  manually/via push API). This can be mitigated by using the push API to
  update the index synchronously right after a write, for data that must be
  searchable immediately (e.g., a newly created Venue).
- *It is not a system of record*: the index is a derived, denormalized copy
  of the data, so the source database (Azure SQL, in this project's case)
  must remain the source of truth, and the two can drift out of sync between
  indexer runs. Mitigation: keep write operations going through the
  application/EF Core as normal, and treat the search index purely as a
  read-optimised, eventually-consistent view.
- *Relevance tuning has a learning curve*: getting scoring profiles, synonyms
  and semantic ranking configured well for a specific domain takes iteration
  and testing, unlike a simple `LIKE` query whose behaviour is fully
  predictable.

## 2. Why normalization matters in cloud-based database design

Normalization — structuring tables so that each fact is stored exactly once
and organised around functional dependencies (2NF/3NF, etc.) — matters in
the cloud for largely the same reasons it matters on-premises, but the
cost/scale dynamics of the cloud sharpen the trade-offs:

- **Data integrity and reduced anomalies**: In EventEase, `Venue`,
  `Event`, and `Booking` are kept as separate normalized tables rather than
  copying venue details onto every event row. This means updating a venue's
  capacity or location happens in exactly one place, and there is no risk of
  two "copies" of the same venue drifting apart — an update, insert, or
  delete anomaly that denormalized designs are prone to.
- **Storage efficiency at scale**: Cloud databases (Azure SQL, Cosmos DB)
  are typically billed by provisioned capacity/DTUs, storage consumed, and/or
  throughput (RU/s). Normalized schemas avoid redundant storage of repeated
  data, which directly reduces cost as the dataset scales into millions of
  rows.
- **Consistency across distributed/replicated environments**: cloud
  databases are frequently geo-replicated for availability. Redundant,
  denormalized copies of the same fact multiply the surface area for
  replication conflicts and inconsistency during synchronization.

**Impact of normalized vs. denormalized structures on performance and
scalability in Azure:**

- *Normalized structures* keep writes cheap and consistent (a single-row
  update), and they keep the schema flexible for evolving business rules —
  but reads that need a "whole picture" (e.g., the Bookings management
  screen, which needs event *and* venue details together) require **joins**
  across tables. Joins are more expensive computationally and, in
  distributed cloud databases that shard data (e.g. Cosmos DB, or
  horizontally-partitioned Azure SQL), a join across partitions can be
  significantly slower than a query against a single partition.
- *Denormalized structures* (or purpose-built read models, like this
  project's `vw_BookingDetails` view) trade some storage redundancy and
  write complexity for much cheaper, faster reads — there's no join needed
  at query time, which matters more as request volume grows and read
  latency becomes user-facing. This is precisely why EventEase introduces
  `vw_BookingDetails` as a **view** rather than duplicating columns in the
  `Bookings` table itself: it gets the read-side convenience of a
  denormalized shape, computed on demand from the normalized source tables,
  without ever risking the two falling out of sync (the view *is* the join,
  always up to date, with no extra storage cost).
- In very large or globally-distributed cloud systems, teams often go
  further and intentionally denormalize into a separate read-optimized
  store (a search index, a cache, a reporting table refreshed by an Azure
  Function) specifically because joining normalized data at cloud scale, on
  every request, does not scale — this is the classic CQRS
  (Command Query Responsibility Segregation) pattern.

## 3. Relational vs. NoSQL cloud databases

*(Referenced context for the comparison used above and throughout this
project, which uses Azure SQL Database — a relational, schema-based cloud
database.)*

| | Relational (e.g. Azure SQL Database) | NoSQL (e.g. Azure Cosmos DB) |
|---|---|---|
| **Schema** | Fixed, enforced schema with typed columns, foreign keys and constraints | Flexible/schema-less; documents in the same container can have different shapes |
| **Consistency model** | Strong (ACID) transactions, including across multiple tables | Configurable — Cosmos DB offers five consistency levels from strong to eventual, trading consistency for latency/availability |
| **Query model** | SQL, with joins across normalized tables | Varies by API — SQL-like queries (Core/SQL API), document queries, graph traversal, key-value, or column-family, generally optimized for querying within a single partition/document |
| **Scaling** | Primarily vertical (bigger compute tier), with some horizontal options (elastic pools, sharding) | Horizontal by design — partitioned/sharded across nodes, built for massive scale-out |
| **Best fit** | Data with clear relationships and strong integrity needs — exactly EventEase's Venue/Event/Booking relationships, where double-booking rules and referential integrity (you cannot delete a Venue with active Bookings) depend on enforced foreign keys and transactions | High-volume, high-velocity, loosely-structured data — e.g. IoT telemetry, session/state data, product catalogues with varying attributes, or globally-distributed apps needing low-latency reads/writes close to users |

For EventEase, a relational database is the right fit precisely because the
core business rules (no double-booking a venue, no deleting a venue/event
with active bookings) are relational-integrity problems, well expressed
through foreign keys, constraints, and transactions. A NoSQL store would
require re-implementing that integrity logic entirely in application code.

## 4. How Durable Functions can benefit a cloud application's performance

Azure Durable Functions is an extension of Azure Functions that lets you
write **stateful, long-running, and orchestrated workflows** using normal
code, while the Durable Functions framework handles checkpointing state and
resuming execution reliably (including across process restarts) — without
you having to manage a message queue or a state machine by hand.

Concrete ways this could benefit a cloud application like EventEase:

- **Offloading slow work from the request/response cycle.** Image upload
  to Blob Storage could be extended with a follow-up **Durable Function
  Orchestration** that generates a thumbnail, virus-scans the file, and
  updates the Venue/Event record with the final processed URL — all
  triggered asynchronously by a Blob Storage trigger, rather than blocking
  the user's HTTP request until every step completes. This keeps the web
  app responsive.
- **Fan-out/fan-in for bulk operations.** If a booking specialist needed to
  send confirmation emails/notifications for many bookings at once (e.g. a
  bulk reminder job the night before an event), a Durable Function can fan
  out to process each booking in parallel and fan back in once all are
  done, which is both faster and easier to reason about than a hand-rolled
  parallel loop with manual retry logic.
- **Reliable multi-step workflows with retries.** A booking-confirmation
  workflow that (1) reserves the venue, (2) charges a deposit via a payment
  API, and (3) sends a confirmation email is a natural fit for the Durable
  Functions **Function Chaining** pattern: each step is automatically
  checkpointed, so if step 2 fails transiently, the orchestration can retry
  just that step (with configurable retry policies) instead of restarting
  the whole process or leaving data in an inconsistent state.
- **Reduced infrastructure cost/idle compute.** Because Azure Functions
  (including Durable Functions on the Consumption plan) scale to zero and
  bill per execution, moving background/orchestration work out of the
  always-on web app and into event-driven functions can reduce the compute
  footprint (and cost) needed to keep the main application responsive,
  while still handling bursty or long-running work reliably.

In short, Durable Functions improve *perceived* application performance by
moving slow, multi-step, or bulk work off the synchronous request path,
while improving *actual* reliability through automatic state checkpointing
and retry — both of which matter more as a cloud application like EventEase
grows beyond a simple CRUD workload.
