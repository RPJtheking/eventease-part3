# EventEase — Part 2 Deployment Guide

This document covers the steps to deploy the Part 2 changes: Azure Blob Storage
for images, the new `vw_BookingDetails` view, and republishing the web app.

## 1. Create the Azure Storage account (Blob Storage)

1. In the Azure Portal, create a new **Storage account** (Standard performance,
   LRS redundancy is fine for this project).
2. Once created, go to **Security + networking → Access keys** and copy a
   **Connection string**.
3. You do **not** need to manually create the blob container — the app creates
   it automatically on first upload (`CreateIfNotExistsAsync`, set to public
   *Blob* access so `<img>` tags can load the images directly).

## 2. Configure the connection string

**Locally (development):** the project's `appsettings.Development.json` is
pre-set to `UseDevelopmentStorage=true`, which targets the
[Azurite storage emulator](https://learn.microsoft.com/azure/storage/common/storage-use-azurite).
Install/run Azurite (`npm install -g azurite` then `azurite`) or use the
Azurite extension in VS Code before running the app locally.

**On Azure App Service (production):** never commit a real connection string
to `appsettings.json`. Instead, set it as an **Application Setting** on the
App Service:

- Key: `AzureBlobStorage__ConnectionString` (double underscore — this is how
  ASP.NET Core maps flat environment variables to nested configuration
  sections)
- Value: the connection string copied in step 1

Optionally also set `AzureBlobStorage__ContainerName` if you want a container
name other than the default `eventease-images`.

## 3. Update the Azure SQL Database with the new view and double-booking index

The `AddBookingDetailsView` migration both relaxes `Venues.ImageUrl` to be
nullable and creates the `vw_BookingDetails` view that the Bookings page now
reads from. The `AddBookingDoubleBookingIndex` migration adds a unique
`(VenueId, BookingDate)` index that enforces the "no double-booking at the
same date and time" rule at the database level, as a safety net behind the
application-level check in `BookingsController`.

From the `EventEase` project folder, pointed at your Azure SQL connection
string (either via `appsettings.json` temporarily, or `dotnet user-secrets`):

```bash
dotnet ef database update
```

This applies `InitialCreate`, `AddBookingDetailsView`, and
`AddBookingDoubleBookingIndex` (whichever haven't already been applied). If you prefer to run the view creation manually in
SQL Server Object Explorer / Azure Data Studio, the script is:

```sql
ALTER TABLE Venues ALTER COLUMN ImageUrl nvarchar(max) NULL;
GO

CREATE VIEW vw_BookingDetails AS
SELECT
    b.BookingId,
    b.BookingDate,
    e.EventId,
    e.EventName,
    e.EventDate,
    e.Description AS EventDescription,
    e.ImageUrl     AS EventImageUrl,
    v.VenueId,
    v.VenueName,
    v.Location      AS VenueLocation,
    v.Capacity        AS VenueCapacity,
    v.ImageUrl          AS VenueImageUrl
FROM dbo.Bookings b
INNER JOIN dbo.Events e ON e.EventId = b.EventId
INNER JOIN dbo.Venues v ON v.VenueId = b.VenueId;
GO
```

## 4. Publish the updated web application

Using Visual Studio's existing publish profile (`Properties/PublishProfiles`):

1. Right-click the project → **Publish** → select the existing
   `EventEase - Web Deploy` profile.
2. Click **Publish**. This redeploys the updated controllers, views, and the
   `Azure.Storage.Blobs` dependency.

Or via the CLI:

```bash
dotnet publish -c Release
# then deploy the contents of bin/Release/net8.0/publish via Azure CLI /
# `az webapp deploy`, or your existing Web Deploy profile.
```

## 5. Post-deployment checklist

- [ ] `AzureBlobStorage__ConnectionString` app setting is set on the App
      Service and does **not** contain a placeholder value.
- [ ] `dotnet ef database update` has been run against the Azure SQL
      Database, and `vw_BookingDetails` exists (verify in Object Explorer).
- [ ] Creating a Venue/Event with a new image successfully shows the image
      loading from a `https://<storageaccount>.blob.core.windows.net/...` URL.
- [ ] The Bookings page search box finds a booking both by typing its numeric
      ID and by typing (part of) an event name.
- [ ] Attempting to delete a Venue/Event that has active bookings is blocked
      with an explanatory message.
- [ ] Booking the same venue for two different events at the same date and
      time is blocked with a validation alert.
