# EventEase — Part 3 Deployment Guide

Deploys the filter feature (EventTypes lookup, venue availability, search filters) and
updates the Azure SQL database. Part 2 steps (Blob Storage account, connection string app
setting) are unchanged — see `DEPLOYMENT_PART2.md`.

## 1. Back up the database (recommended)
In the Azure Portal open the SQL database → **Export**, or rely on the point-in-time restore
that Azure SQL provides. The migration only adds objects and rebuilds a view, but a backup is cheap insurance.

## 2. Update the Azure SQL database

**Option A — EF Core migration (recommended).** From the `EventEase` project folder, with the
Azure SQL connection string supplied through `dotnet user-secrets` (or temporarily in `appsettings.json` —
never commit it):

```bash
dotnet user-secrets set "ConnectionStrings:DefaultConnection" "<azure-sql-connection-string>"
dotnet ef database update
```

This applies `AddEventTypeAndVenueAvailability`, which:
1. creates the `EventTypes` table and inserts the eight predefined categories,
2. adds `Venues.IsAvailable` (existing venues default to *available*),
3. adds `Events.EventTypeId` (nullable FK) and classifies the three seeded events,
4. rebuilds `vw_BookingDetails` with the new columns.

The web app also calls `Database.Migrate()` at startup, so a successful deployment will apply it
automatically if the App Service's connection string has permission to alter the schema.

**Self-healing:** the Part 3 changes are written as idempotent SQL (`Data/Part3Schema.cs`), used both by the
migration and by a startup safety net in `Program.cs`. If the migration fails for any reason, the app logs the real
error (`Database migration failed: ...`) and applies the same changes directly, so Venues and Events keep working.
Running it more than once is harmless.

**Option B — SQL script.** Open `EventEase/Database/Part3_EventTypeAndAvailability.sql` in Azure Data Studio
or the portal's Query editor and run it. It is idempotent and records the migration in `__EFMigrationsHistory`.

Make sure the Azure SQL **firewall** allows your IP (SQL server → Networking → Add your client IPv4).

## 3. Publish the web application
Visual Studio: right-click the project → **Publish** → select the existing `EventEase - Web Deploy`
profile → **Publish**.

CLI alternative:
```bash
dotnet publish -c Release -o ./publish
cd publish && zip -r ../eventease.zip . && cd ..
az webapp deploy --resource-group rg-EventEase-SANorth --name EventEase20260909092006 --src-path eventease.zip --type zip
```

## 4. App Service configuration (unchanged but worth re-checking)
- `ConnectionStrings:DefaultConnection` (Connection strings blade, type *SQLAzure*).
- `AzureBlobStorage__ConnectionString` (Application setting).

Live site: https://eventease20260909092006.azurewebsites.net

## 5. Post-deployment checklist
- [ ] `EventTypes` table exists with 8 rows; `Venues.IsAvailable` and `Events.EventTypeId` columns exist.
- [ ] `SELECT * FROM vw_BookingDetails` returns `EventTypeName` and `VenueIsAvailable`.
- [ ] Event Create/Edit shows the **Event Type** drop-down; Venue Create/Edit shows **Available for booking**.
- [ ] `/Search` shows the filter panel; filtering by type, dates and availability returns the expected results
      (see "Testing the filters" in `README_PART3.md`).
- [ ] Booking a venue marked unavailable is blocked.
- [ ] Part 2 features still work: image upload to Blob Storage, double-booking prevention, booking search.

## 6. Troubleshooting
In Development the real exception is shown on the page (developer exception page) and in the console/Output window.
In production it is logged (App Service → Log stream) and users see the friendly error page.

| Symptom | Likely cause / fix |
|---|---|
| "The search filters are unavailable right now" / "We couldn't load the venues/events" | Database not updated yet — run step 2 (or restart the app so the startup safety net runs). |
| Bookings page says the view is unavailable | `vw_BookingDetails` missing or outdated — re-run the migration/script. |
| `Invalid column name 'IsAvailable'` | Code deployed before the database was updated — run step 2. |
| Cannot connect to SQL | Firewall rule, or wrong connection string on the App Service. |
