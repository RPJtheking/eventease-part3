# EventEase — Part 3 Theory Answers

## 1. How Cosmos DB differs from traditional databases

EventEase uses **Azure SQL Database**, a traditional relational database. **Azure Cosmos DB** is a
globally distributed, multi-model NoSQL service. The main differences:

| | Traditional relational (Azure SQL) | Azure Cosmos DB |
|---|---|---|
| **Data model** | Tables, rows, typed columns, foreign keys | Schema-agnostic JSON documents (also key-value, graph, column-family APIs) in containers |
| **Schema** | Fixed and enforced; changes need migrations (as with `AddEventTypeAndVenueAvailability`) | Flexible; documents in one container may have different shapes, so fields can be added without a migration |
| **Querying** | T-SQL with joins across normalized tables | SQL-like API over documents; joins are limited to within a single document, so data is usually **denormalized/embedded** |
| **Scaling** | Mostly vertical (bigger tier); read replicas and sharding take extra work | **Horizontal** scale-out via partitioning on a *partition key*; elastic throughput measured in Request Units (RU/s) |
| **Distribution** | Geo-replication available, typically one writer | Turnkey **multi-region replication** with optional multi-region writes |
| **Consistency** | Strong ACID transactions across tables | Five tunable consistency levels (strong, bounded staleness, session, consistent prefix, eventual); transactions only within a partition |
| **Latency/SLA** | Depends on tier and query plan | Single-digit-millisecond reads/writes and SLAs on throughput, latency, availability and consistency |
| **Cost model** | DTU/vCore tier + storage | Provisioned or autoscale RU/s + storage; poor partition keys can create expensive "hot" partitions |

**When each fits EventEase.** The relational model suits the core booking data: Venues, Events and
Bookings are strongly related, and the unique `(VenueId, BookingDate)` index relies on
relational constraints and transactions to guarantee no double bookings. Cosmos DB would be attractive for
high-volume, loosely structured, globally accessed data — e.g. an activity/audit log, per-user session data,
or a venue catalogue with very different attributes per venue type — where horizontal scale and
low latency matter more than joins. Many real systems use both (polyglot persistence).

## 2. Key considerations when designing Logic Apps that handle sensitive data

1. **Secure inputs and outputs.** Run history stores every action's inputs and outputs in clear text by default.
   Enable *Secure Inputs* / *Secure Outputs* on actions that touch personal or financial data so they are
   masked in run history and the monitoring tools.
2. **No secrets in the workflow definition.** Keep connection strings, keys and passwords in **Azure Key Vault**
   and read them via managed identity or secure parameters, not hard-coded values.
3. **Identity and least privilege.** Use a **managed identity** to call other Azure services instead of shared
   keys, and grant only the roles needed (e.g. *Storage Blob Data Reader*, not Owner). Use Azure RBAC to control
   who can edit or view run history.
4. **Protect the trigger.** Restrict who can call HTTP-triggered workflows: OAuth/Microsoft Entra authorisation,
   IP restrictions, or placing the Logic App behind API Management rather than exposing the callback URL with its SAS key.
5. **Network isolation.** For sensitive workloads use Standard Logic Apps with VNet integration and private
   endpoints so traffic to SQL, Storage and Key Vault stays off the public internet.
6. **Encryption.** Data is encrypted in transit (TLS) and at rest; consider customer-managed keys where policy requires it.
7. **Data minimisation and retention.** Pass IDs instead of full records where possible, avoid copying sensitive
   fields into emails/messages, and set run-history retention to the shortest period that meets audit needs.
8. **Compliance (POPIA/GDPR).** Keep data in an approved region (e.g. South Africa North), log who accessed what,
   and make sure connectors do not forward personal data to unapproved third parties.
9. **Auditing and monitoring.** Send diagnostic logs to Log Analytics, alert on failed runs and unusual access,
   and add error-handling (`runAfter` scopes) so failures don't leak sensitive payloads into error messages.

## 3. Combining Event Grid with other services to build robust workflows

**Azure Event Grid** is a fully managed event-routing service: *publishers* (event sources) emit events to
*topics*, and *subscriptions* with filters deliver them to *handlers*. It is push-based, scales automatically,
and retries delivery with dead-lettering for failures. It doesn't process anything itself — its value comes from
connecting other services in a loosely coupled, reactive way:

- **Blob Storage → Event Grid → Azure Function.** When an event image is uploaded to the `eventease-images`
  container, a `BlobCreated` event triggers a Function that resizes it, scans it, or records metadata — no polling.
- **Event Grid → Logic App.** A *"BookingCreated"* custom event triggers a Logic App that emails the customer,
  posts to Teams and updates a CRM, with the workflow designer handling the connectors.
- **Event Grid → Service Bus / Event Hubs.** Fan-out events into a queue for reliable, ordered, back-pressured
  processing, or stream them to analytics.
- **Event Grid → Azure SQL / Cosmos DB (via Functions).** Keep a read-model or search index (Azure AI Search)
  in sync after data changes.

**Why this is robust:**
- *Loose coupling* — publishers don't know who consumes events, so new consumers (reporting, notifications)
  can be added without changing the booking app.
- *Reliability* — at-least-once delivery, exponential-backoff retries and dead-letter storage mean events
  aren't silently lost (handlers should therefore be idempotent).
- *Filtering and routing* — subscription filters on event type/subject send each handler only what it needs.
- *Scalability and cost* — serverless, pay-per-event, scales to high volume.
- *Security* — Entra ID/managed identity authentication and endpoint validation protect subscriptions.

A concrete EventEase flow: **booking saved → custom event published to Event Grid → (1) Logic App sends a
confirmation, (2) Function updates the search index, (3) Service Bus queue feeds a billing process.**
Each step can fail and retry independently without blocking the user's booking.
