# EventEase — Part 3: Advanced Filtering, Final Deployment and Reflection

Built on top of the Part 2 project. See `docs/DEPLOYMENT_PART3.md` for the deployment
steps, `docs/THEORY_ANSWERS_PART3.md` for the theory answers and
`docs/REFLECTION_PART3.md` for the project reflection.

## What changed from Part 2

### A. Advanced filtering
- **New `EventTypes` lookup table** (`Models/EventType.cs`) seeded with eight predefined
  categories: Wedding, Conference, Gala / Fundraiser, Corporate Function,
  Birthday / Celebration, Concert / Performance, Exhibition / Expo, Other.
- **`Event.EventTypeId`** (optional foreign key) — chosen from a drop-down on the
  Event Create/Edit forms, shown on the Events list and details pages. The three seeded
  events are classified.
- **`Venue.IsAvailable`** (bool, default `true`) — a checkbox on the Venue Create/Edit forms,
  shown as an Available/Unavailable badge. Bookings can no longer be created for a venue
  that is marked unavailable.
- **Search filters** on `/Search` (`SearchController` + `Views/Search/Index.cshtml`):

  | Filter | Applies to |
  |---|---|
  | Event type | Events and Bookings of that type; Venues that host events of that type |
  | Date range (from / to, inclusive) | Events and Bookings by **event date** |
  | Venue availability (Any / Available / Unavailable) | Venues, plus the Events and Bookings held at matching venues |

  - The keyword box is now **optional** — filters alone are enough to run a search, and all
    filters combine with each other and with the keyword.
  - **"Available"** means the venue is flagged available **and** has no bookings inside the
    chosen date range (with no date range, it is just the flag). "Unavailable" is the exact opposite.
  - If the dates are entered the wrong way round they are swapped, with a notice.
- The **Events** list also has an event-type filter and the **Venues** list an availability filter.
- `vw_BookingDetails` was rebuilt to include `EventTypeId`, `EventTypeName` and `VenueIsAvailable`
  (LEFT JOIN, since an event's type is optional).

### B. Database changes
- Migration `20260930100000_AddEventTypeAndVenueAvailability` creates `EventTypes`, adds
  `Venues.IsAvailable` and `Events.EventTypeId` (with index + FK), seeds the lookup rows
  and rebuilds the view. The app applies it automatically at startup (`db.Database.Migrate()`),
  or run `dotnet ef database update`.
- The changes live in `Data/Part3Schema.cs` as idempotent SQL batches, shared by the migration and a startup safety
  net in `Program.cs`, so a partly-updated or failed migration can no longer leave Venues/Events broken.
- `EventEase/Database/Part3_EventTypeAndAvailability.sql` is an idempotent manual alternative.
- In Development the real exception is now displayed instead of the generic "Oops" page; Venues/Events lists show a
  clear message instead of crashing if the database is out of date.

### C. Deployment and documentation
- `docs/DEPLOYMENT_PART3.md` — republishing to Azure App Service and updating Azure SQL.
- `docs/THEORY_ANSWERS_PART3.md` — Cosmos DB vs traditional databases, Logic Apps with sensitive
  data, Event Grid workflows.
- `docs/REFLECTION_PART3.md` — draft reflection on the project and cloud skills.

## Testing the filters (after deploying)
1. Search with no keyword, event type **Wedding** → *Smith Wedding*, its booking, and *Garden Pavilion*.
2. Date from `2026-10-01` to `2026-10-31` → only *Annual Tech Conference*.
3. Edit *Riverside Hall* and untick **Available**, then filter Availability = **Unavailable** → it appears.
4. Try creating a booking for *Riverside Hall* → blocked with an alert.
5. Availability = **Available** with a date range covering a booked date → that venue is excluded.
