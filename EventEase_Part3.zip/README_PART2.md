# EventEase — Part 2: Enhancing Functionality and Integrating Cloud Storage

This zip contains the Part 1 EventEase source with Part 2 requirements
implemented on top of it. See `docs/DEPLOYMENT_PART2.md` for deployment
steps and `docs/THEORY_ANSWERS_PART2.md` for the written theory answers.

## What changed from Part 1

### A. Azure Storage integration
- Added `Services/IBlobStorageService.cs` + `BlobStorageService.cs`, wrapping
  the `Azure.Storage.Blobs` SDK.
- `Venue` and `Event` now expose an `ImageFile` (`IFormFile`, not persisted)
  used by the Create/Edit forms; `ImageUrl` is set server-side after a
  successful upload to Blob Storage (see `AzureBlobStorage` in
  `appsettings.json`).
- Old images are deleted from the container when replaced or when the
  parent Venue/Event is deleted.

### B. Error handling and validation
- Double-booking prevention (same venue, same date **and time**, two
  different events) on both Create and Edit, enforced at the application
  level and backed by a unique `(VenueId, BookingDate)` database index,
  surfaced as a validation error **and** a JavaScript alert
  (`wwwroot/js/site.js` → `showValidationAlert()`).
- Deleting a Venue or Event with active Bookings is blocked with an
  explanatory message.
- Every controller action that writes to the database or uploads a file is
  wrapped in try/catch, so common user errors (missing required field, bad
  image type/size, concurrent edits) surface as a friendly message instead
  of crashing the request.
- Added `Middleware/ExceptionHandlingMiddleware.cs` as a global safety net
  for anything unhandled, redirecting to a friendly `/Home/Error` page.
- `data-confirm` attributes on destructive delete forms trigger a
  confirmation prompt before submitting.

### C. Enhanced display and search
- New `vw_BookingDetails` SQL view (see migration
  `20260916120000_AddBookingDetailsView`) joins Booking + Event + Venue into
  one consolidated read model.
- `Models/BookingDetailsView.cs` is a keyless EF Core entity mapped to that
  view via `ToView("vw_BookingDetails")`.
- `Bookings/Index` now reads from this view and supports searching by
  **BookingID** (numeric match) or **Event Name** (partial match) from a
  single search box, while also displaying venue location/capacity inline.
- A **site-wide search bar** is built into the navigation bar (`_Layout.cshtml`)
  and appears on every page. It posts to `SearchController`, which queries
  Venues, Events, and the `vw_BookingDetails` view in parallel and returns a
  single results page (`Views/Search/Index.cshtml`) grouped by type, so a
  booking specialist can search for a venue, event, or booking from anywhere
  in the app without first navigating to that section.

### D. Azure deployment updates
- See `docs/DEPLOYMENT_PART2.md` for storage account setup, app settings,
  running `dotnet ef database update` against Azure SQL, and republishing.

### E. Database design & Cognitive Search theory
- See `docs/THEORY_ANSWERS_PART2.md`.
